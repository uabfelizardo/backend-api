Este projeto de api foi desenvolvido no âmbito do trabalho em grupo para a unidade curricular Desenvolvimento de Aplicações Móveis (DAM)

A api foi concebida em Node.js usando o Express que é um framework de estrutura leve e flexível para criar aplicativos da web e APIs em Node.js.

Aplicação para Consultas Médicas
Online Doctor

Felizardo Chaguala - 2302578
Inês Martins - 2302581
Ornêlo Kambonga – 2302601
Yolanda Marchone - 2302613

git clone https://github.com/uabfelizardo/backend-api.git
Free hosting online details

Nome da base de dados: onlinedoctordb
Platoforma/Servidor de Base de Dados: MySQL versão 5.6

freesqldatabase.com
Host: sql8.freesqldatabase.com 
Database name: sql8701730 
Database user: sql8701730 
Database password: 5AuPUXr28q 
Port number: 3306